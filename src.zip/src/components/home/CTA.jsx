import React from 'react'

const CTA = () => {
  return (
    <>
    <section className="section text-center reveal">
        <div className="container">
            <h2 className="section-title">Your story begins tonight</h2>
            <p className="section-sub">Don't let another twilight pass by. Join the most exclusive community of romantics worldwide and find your lavender spark.</p>
            <a href="signup.html" className="btn btn-spark glow">Get Started</a>
        </div>
    </section>
    </>
  )
}

export default CTA
