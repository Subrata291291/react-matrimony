import React from 'react'

const Hero = () => {
  return (
    <>
      <div className="hero">
        <div>
            <h1 className="fade-up">Find your <em>spark</em><br/>in a garden of lavender</h1>
            <p className="fade-up d1">Step away from the noise and into a curated space of deep connections, where intimacy is always exactly that — exactly that.</p>
            <div className="fade-up d2">
            <a href="signup.html" className="btn btn-spark me-2">Join Now</a>
            <a href="#experience" className="btn btn-ghost">Learn More</a>
            </div>
        </div>
    </div>
    </>
  )
}

export default Hero
