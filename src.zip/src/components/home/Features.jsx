import React from 'react'

const Features = () => {
  return (
    <>
      <section className="section pt-0">
        <div className="container">
            <h2 className="section-title reveal">The Spark Gallery</h2>
            <p className="section-sub reveal">Witness the chemistry of Spark. Real stories, real moments, captured live.</p>
            <div className="gallery reveal">
            <div className="g-item"><img src="images/g1.jpg" alt="" /><div className="cap">Emi & Sarah · Last Saturday</div></div>
            <div className="g-item"><img src="images/g2.jpg" alt="" /></div>
            <div className="g-item"><img src="images/hero.jpg" alt="" /></div>
            <div className="g-item"><img src="images/elena.jpg" alt="" /></div>
            <div className="g-item"><img src="images/julian.jpg" alt="" /></div>
            </div>
        </div>
    </section>
    </>
  )
}

export default Features
