import React from "react";
import { Link, NavLink } from "react-router-dom";

const Navbar = () => {
  return (
    <nav className="navbar navbar-expand-lg navbar-spark fixed-top">
      <div className="container">
        {/* Logo */}
        <Link className="brand" to="/">
          ✦ Spark
        </Link>

        {/* Mobile Toggle */}
        <button
          className="navbar-toggler text-light border-0"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#nav"
          aria-controls="nav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <i className="bi bi-list fs-3"></i>
        </button>

        {/* Menu */}
        <div
          className="collapse navbar-collapse justify-content-end"
          id="nav"
        >
          <NavLink
            to="/"
            className={({ isActive }) =>
              `nav-link ${
                isActive ? "active" : ""
              }`
            }
          >
            Home
          </NavLink>

          <NavLink
            to="/discover"
            className={({ isActive }) =>
              `nav-link ${
                isActive ? "active" : ""
              }`
            }
          >
            Discover
          </NavLink>

          <NavLink
            to="/messages"
            className={({ isActive }) =>
              `nav-link ${
                isActive ? "active" : ""
              }`
            }
          >
            Messages
          </NavLink>

          <NavLink
            to="/profile"
            className={({ isActive }) =>
              `nav-link ${
                isActive ? "active" : ""
              }`
            }
          >
            Profile
          </NavLink>

          {/* CTA Button */}
          <Link
            to="/signup"
            className="btn btn-spark ms-3"
          >
            Join Spark
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;