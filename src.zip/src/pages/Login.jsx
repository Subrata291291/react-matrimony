import React from "react";

const Login = () => {
  return (
    <div className="auth-wrap">
      <div className="auth-card tilt-3d" data-tilt>
        <div className="tilt-inner">
          {/* Header */}
          <div className="text-center mb-4">
            <a
              href="/"
              className="brand"
              style={{ fontSize: "2rem" }}
            >
              ✦ Spark
            </a>

            <h3 className="mt-2">Welcome back</h3>

            <p className="text-muted-2 small">
              Sign in to rekindle your spark.
            </p>
          </div>

          {/* Form */}
          <form>
            {/* Email */}
            <label>Email</label>

            <input
              type="email"
              className="form-control mb-3"
              placeholder="you@spark.love"
            />

            {/* Password */}
            <label>Password</label>

            <input
              type="password"
              className="form-control mb-3"
              placeholder="••••••••"
            />

            {/* Remember & Forgot */}
            <div className="d-flex justify-content-between small mb-3">
              <label className="text-muted-2">
                <input
                  type="checkbox"
                  className="me-1"
                />
                Remember me
              </label>

              <a href="/forgot-password">
                Forgot password?
              </a>
            </div>

            {/* Submit */}
            <button
              type="button"
              className="btn btn-spark w-100 glow"
            >
              Sign In
            </button>

            {/* Divider */}
            <div className="text-center my-3 text-muted-2 small">
              — or continue with —
            </div>

            {/* Social Login */}
            <div className="d-flex gap-2">
              <button
                type="button"
                className="btn btn-ghost w-100"
              >
                <i className="bi bi-google"></i> Google
              </button>

              <button
                type="button"
                className="btn btn-ghost w-100"
              >
                <i className="bi bi-apple"></i> Apple
              </button>
            </div>

            {/* Signup */}
            <p className="text-center mt-4 text-muted-2 small">
              New here?{" "}
              <a href="/signup">
                Create an account
              </a>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Login;