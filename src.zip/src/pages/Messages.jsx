import React, { useState } from "react";

const Messages = () => {
  const [message, setMessage] = useState("");

  const conversations = [
    {
      id: 1,
      name: "Elena, 28",
      message: "Tomorrow sounds wonderful…",
      image: "images/elena.jpg",
      active: true,
    },
    {
      id: 2,
      name: "Maya",
      message: "Loved the gallery photo!",
      image: "images/g2.jpg",
    },
    {
      id: 3,
      name: "Julian",
      message: "Coffee on Sunday?",
      image: "images/julian.jpg",
    },
  ];

  const chatMessages = [
    {
      id: 1,
      type: "them",
      text: "I really visited that rooftop bar you mentioned. You were right about that lavender Gin Fizz — it's dangerous!",
    },
    {
      id: 2,
      type: "them",
      text: "I bet! The way you find a hidden detail every visit. It reminded me of your reflections virtually. For one time it's incredible at night… 🌙",
    },
    {
      id: 3,
      type: "me",
      text: "That's quite the compliment. We should go together one of these nights. Have you tried the 'Spark' rooftop yet?",
    },
    {
      id: 4,
      type: "them",
      text: "Tomorrow sounds wonderful. Pick me up at 8? ✦",
    },
  ];

  const sharedVibes = [
    "Art Lover",
    "Wanderlust",
    "Foodie",
    "Bookworm",
  ];

  return (
    <main
      className="container"
      style={{
        paddingTop: "110px",
        paddingBottom: "60px",
      }}
    >
      <div className="messages-wrap reveal">
        {/* Conversations */}
        <div className="convo-list">
          <div
            className="p-3 border-bottom"
            style={{
              borderColor: "var(--border)",
            }}
          >
            <h5 className="m-0">
              <i
                className="bi bi-chat-heart-fill"
                style={{ color: "var(--accent)" }}
              ></i>{" "}
              Messages
            </h5>
          </div>

          {conversations.map((item) => (
            <div
              key={item.id}
              className={`convo-item ${
                item.active ? "active" : ""
              }`}
            >
              <img
                className="avatar"
                src={item.image}
                alt={item.name}
              />

              <div>
                <strong>{item.name}</strong>

                <div className="small text-muted-2">
                  {item.message}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Chat Panel */}
        <div className="chat-panel">
          {/* Header */}
          <div className="chat-header">
            <img
              className="avatar"
              src="images/elena.jpg"
              alt="Elena"
            />

            <div className="flex-grow-1">
              <strong>Elena, 28</strong>

              <div className="small text-muted-2">
                Active now
              </div>
            </div>

            <i className="bi bi-telephone fs-5 text-muted-2"></i>

            <i className="bi bi-camera-video fs-5 ms-3 text-muted-2"></i>

            <i className="bi bi-three-dots fs-5 ms-3 text-muted-2"></i>
          </div>

          {/* Chat Body */}
          <div className="chat-body" id="chatBody">
            <div className="text-center small text-muted-2">
              — Yesterday · 8:42 PM —
            </div>

            {chatMessages.map((msg) => (
              <div
                key={msg.id}
                className={`bubble ${msg.type}`}
              >
                {msg.text}
              </div>
            ))}
          </div>

          {/* Chat Input */}
          <div className="chat-input">
            <input
              id="chatInput"
              placeholder="Type your message…"
              value={message}
              onChange={(e) =>
                setMessage(e.target.value)
              }
            />

            <button className="btn btn-spark">
              <i className="bi bi-send-fill"></i>
            </button>
          </div>
        </div>

        {/* Insights */}
        <div
          className="insight-panel"
          style={{ padding: "20px" }}
        >
          <h5 className="mb-3">Match Insights</h5>

          <div className="text-center mb-3">
            <div className="compat-ring float">
              <span>96%</span>
            </div>

            <div className="mt-2 text-muted-2 small">
              Compatibility
            </div>
          </div>

          <h6 className="text-muted-2 small text-uppercase">
            Shared Vibes
          </h6>

          <div className="mb-3">
            {sharedVibes.map((vibe, index) => (
              <span
                key={index}
                className={`chip ${
                  index < 2 ? "active" : ""
                }`}
              >
                {vibe}
              </span>
            ))}
          </div>

          <h6 className="text-muted-2 small text-uppercase">
            Conversation Starters
          </h6>

          <div
            className="card-spark mb-2"
            style={{ padding: "12px" }}
          >
            <small>
              "The rooftop she loves has a 100-year-old
              story — ask about it."
            </small>
          </div>

          <div
            className="card-spark"
            style={{ padding: "12px" }}
          >
            <small>
              "Suggest the lavender festival next month."
            </small>
          </div>

          <a
            href="/signup"
            className="btn btn-spark w-100 mt-3"
          >
            Upgrade to Gold
          </a>
        </div>
      </div>
    </main>
  );
};

export default Messages;