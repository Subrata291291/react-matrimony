import React, { useState } from "react";

const Register = () => {
  const [selectedGoal, setSelectedGoal] =
    useState("Long term");

  const relationshipGoals = [
    "Long term",
    "Marriage",
    "Friendship",
    "Open to anything",
  ];

  return (
    <div className="auth-wrap">
      <div className="auth-card tilt-3d" data-tilt>
        <div className="tilt-inner">
          {/* Header */}
          <div className="text-center mb-4">
            <a
              href="/"
              className="brand"
              style={{ fontSize: "2rem" }}
            >
              ✦ Spark
            </a>

            <h3 className="mt-2">
              Begin your story
            </h3>

            <p className="text-muted-2 small">
              Join the most curated community of
              romantics.
            </p>
          </div>

          {/* Form */}
          <form>
            {/* Name & Age */}
            <div className="row g-2">
              <div className="col-6">
                <label>First name</label>

                <input
                  type="text"
                  className="form-control"
                  placeholder="Julian"
                />
              </div>

              <div className="col-6">
                <label>Age</label>

                <input
                  type="number"
                  className="form-control"
                  placeholder="29"
                />
              </div>
            </div>

            {/* Email */}
            <label className="mt-3">
              Email
            </label>

            <input
              type="email"
              className="form-control"
              placeholder="you@spark.love"
            />

            {/* Password */}
            <label className="mt-3">
              Password
            </label>

            <input
              type="password"
              className="form-control"
              placeholder="At least 8 characters"
            />

            {/* Looking For */}
            <label className="mt-3">
              Looking for
            </label>

            <div className="mt-1">
              {relationshipGoals.map(
                (goal, index) => (
                  <span
                    key={index}
                    className={`chip ${
                      selectedGoal === goal
                        ? "active"
                        : ""
                    }`}
                    onClick={() =>
                      setSelectedGoal(goal)
                    }
                    style={{
                      cursor: "pointer",
                    }}
                  >
                    {goal}
                  </span>
                )
              )}
            </div>

            {/* Terms */}
            <div className="form-check mt-3">
              <input
                className="form-check-input"
                type="checkbox"
                id="tc"
                defaultChecked
              />

              <label
                className="form-check-label small text-muted-2"
                htmlFor="tc"
              >
                I agree to Spark's Terms &
                Community Guidelines.
              </label>
            </div>

            {/* Submit */}
            <button
              type="button"
              className="btn btn-spark w-100 glow mt-3"
            >
              Create Account
            </button>

            {/* Login */}
            <p className="text-center mt-4 text-muted-2 small">
              Already a member?{" "}
              <a href="/login">
                Sign in
              </a>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Register;