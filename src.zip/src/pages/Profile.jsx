import React from "react";

const Profile = () => {
  const coreValues = [
    "Authenticity",
    "Creativity",
    "Growth Mindset",
    "Minimalism",
    "Empathy",
    "Late Nights",
  ];

  const vitals = [
    {
      label: "Location",
      value: "New York · West Village",
    },
    {
      label: "Profession",
      value: "Art Curator",
    },
    {
      label: "Education",
      value: "Master of Fine Arts",
    },
    {
      label: "Lifestyle",
      value: "Occasional Cocktails",
    },
  ];

  const bucketList = [
    "Midnight performance arts in Tokyo's Shimokitazawa.",
    "Volunteer at a sea-turtle sanctuary in the Maldives.",
    "Learning the art of glassblowing in a mountain studio.",
  ];

  return (
    <main
      className="container"
      style={{
        paddingTop: "110px",
        paddingBottom: "60px",
      }}
    >
      {/* Cover */}
      <div className="cover reveal"></div>

      {/* Profile Head */}
      <div className="profile-head reveal">
        <img
          className="pa float"
          src="images/julian.jpg"
          alt="Julian"
        />

        <div className="flex-grow-1">
          <h2 className="m-0">Julian, 29</h2>

          <div className="text-muted-2">
            <i className="bi bi-geo-alt"></i>{" "}
            Curator & Critical Traveler
          </div>
        </div>

        <div className="d-flex gap-2">
          <button className="btn btn-ghost">
            <i className="bi bi-eye"></i> Preview
          </button>

          <button className="btn btn-spark">
            Save Changes
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="row g-4 mt-3">
        {/* Left Side */}
        <div className="col-lg-7">
          {/* Portfolio Gallery */}
          <div className="card-spark reveal">
            <h4>
              Portfolio Gallery
              <span className="float-end small text-muted-2">
                <i className="bi bi-pencil"></i> Manage
              </span>
            </h4>

            <div className="row g-3 mt-1">
              <div className="col-6">
                <div
                  className="g-item"
                  style={{
                    borderRadius: "14px",
                    overflow: "hidden",
                  }}
                >
                  <img
                    src="images/hero.jpg"
                    alt="Gallery"
                    style={{
                      width: "100%",
                      aspectRatio: "4/5",
                      objectFit: "cover",
                    }}
                  />
                </div>
              </div>

              <div className="col-6">
                <div
                  className="g-item"
                  style={{
                    borderRadius: "14px",
                    overflow: "hidden",
                  }}
                >
                  <img
                    src="images/g1.jpg"
                    alt="Gallery"
                    style={{
                      width: "100%",
                      aspectRatio: "4/5",
                      objectFit: "cover",
                    }}
                  />
                </div>
              </div>
            </div>

            <button className="btn btn-ghost mt-3 w-100">
              <i className="bi bi-plus-lg"></i> Add
              Photo
            </button>
          </div>

          {/* Core Values */}
          <div className="card-spark mt-4 reveal">
            <h4>Core Values</h4>

            <div className="mt-2">
              {coreValues.map((value, index) => (
                <span
                  key={index}
                  className={`chip ${
                    index < 2 ? "active" : ""
                  }`}
                >
                  {value}
                </span>
              ))}
            </div>
          </div>

          {/* Soundtrack */}
          <div className="card-spark mt-4 reveal">
            <h4>
              My Soundtrack
              <span
                className="badge ms-2"
                style={{
                  background: "var(--grad)",
                }}
              >
                Premium
              </span>
            </h4>

            <div className="d-flex align-items-center gap-3 mt-3">
              <div
                style={{
                  width: "80px",
                  height: "80px",
                  borderRadius: "14px",
                  background: "var(--grad)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <i className="bi bi-music-note-beamed fs-2 text-white"></i>
              </div>

              <div>
                <div className="text-muted-2 small">
                  Currently looping
                </div>

                <strong
                  style={{ fontSize: "1.2rem" }}
                >
                  Nocturnal Melodies
                </strong>

                <div className="text-muted-2 small">
                  The Midnight Choir
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side */}
        <div className="col-lg-5">
          {/* Narrative */}
          <div className="card-spark reveal">
            <h4>✦ Narrative</h4>

            <p className="text-muted-2">
              A writer of quiet stories in loud cities. I
              spend my days curating digital experiences
              and my nights lost in vinyl records and
              vintage architecture. Looking for someone
              who appreciates the simple things and
              isn't afraid of a sophisticated, soulful
              2am conversation.
            </p>

            <button className="btn btn-ghost btn-sm">
              Edit Bio
            </button>
          </div>

          {/* Vitals */}
          <div className="card-spark mt-4 reveal">
            <h4>Vitals</h4>

            {vitals.map((item, index) => (
              <div
                className="vital"
                key={index}
              >
                <span>{item.label}</span>

                <span>{item.value}</span>
              </div>
            ))}
          </div>

          {/* Bucket List */}
          <div className="card-spark mt-4 reveal">
            <h4>Bucket List</h4>

            <ul className="bucket m-0 p-0">
              {bucketList.map((item, index) => (
                <li key={index}>{item}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </main>
  );
};

export default Profile;