import MainLayout from "../components/layout/MainLayout";

import Hero from "../components/home/Hero";
import Features from "../components/home/Features";
import Gallery from "../components/home/Gallery";
import Journey from "../components/home/Journey";
import Pricing from "../components/home/Pricing";
import CTA from "../components/home/CTA";

function Home() {
  return (
    <MainLayout>
      <Hero />
      <Features />
      <Gallery />
      <Journey />
      <Pricing />
      <CTA />
    </MainLayout>
  );
}

export default Home;