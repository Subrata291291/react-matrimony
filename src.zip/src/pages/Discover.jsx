import React from "react";

const Discover = () => {
  const interests = [
    "Photography",
    "Yoga",
    "Travel",
    "Wine Tasting",
    "Hiking",
    "Cooking",
  ];

  const topPicks = [
    {
      id: 1,
      name: "Sophia",
      age: 26,
      match: "95% match · Travel",
      image: "images/elena.jpg",
    },
    {
      id: 2,
      name: "Isabella",
      age: 29,
      match: "92% match · Yoga",
      image: "images/julian.jpg",
    },
    {
      id: 3,
      name: "Maeve",
      age: 31,
      match: "90% match · Wine",
      image: "images/g2.jpg",
    },
  ];

  return (
    <main
      className="container"
      style={{ paddingTop: "110px", paddingBottom: "60px" }}
    >
      <div className="row g-4">
        {/* Filters */}
        <aside className="col-lg-3">
          <div className="sidebar reveal">
            <h5>
              <i className="bi bi-sliders me-2"></i>
              Filters
            </h5>

            <label className="text-muted-2 small">
              Age Range · 24 – 32
            </label>

            <input
              type="range"
              className="form-range"
              min="18"
              max="60"
              defaultValue="32"
            />

            <label className="text-muted-2 small mt-3">
              Distance · Up to 25 km
            </label>

            <input
              type="range"
              className="form-range"
              min="1"
              max="100"
              defaultValue="25"
            />

            <h5 className="mt-4">Interests</h5>

            <div>
              {interests.map((interest, index) => (
                <span
                  key={index}
                  className={`chip ${index === 0 ? "active" : ""}`}
                >
                  {interest}
                </span>
              ))}
            </div>

            <div className="form-check form-switch mt-4">
              <input
                className="form-check-input"
                type="checkbox"
                id="vo"
                defaultChecked
              />

              <label className="form-check-label" htmlFor="vo">
                Verified Only
              </label>
            </div>

            <button className="btn btn-spark w-100 mt-3">
              Update Search
            </button>
          </div>
        </aside>

        {/* Featured Card */}
        <section className="col-lg-6">
          <div className="profile-card reveal tilt-3d" data-tilt>
            <div className="tilt-inner">
              <div
                className="text-center py-2"
                style={{
                  background: "var(--surface-2)",
                  color: "var(--muted)",
                  fontSize: ".9rem",
                }}
              >
                <i
                  className="bi bi-fire text-accent"
                  style={{ color: "var(--accent)" }}
                ></i>{" "}
                Pick Match
              </div>

              <div className="photo">
                <img src="images/elena.jpg" alt="Elena" />

                <div className="overlay">
                  <h3>Elena, 27</h3>

                  <p className="mb-0 text-muted-2">
                    Marketing Director · 2.5 km away
                  </p>
                </div>
              </div>

              <div className="actions">
                <button className="action-btn">
                  <i className="bi bi-x-lg"></i>
                </button>

                <button className="btn-spark">
                  <i className="bi bi-heart-fill"></i> Send Spark
                </button>

                <button className="action-btn">
                  <i className="bi bi-star-fill"></i>
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Top Picks */}
        <aside className="col-lg-3">
          <div className="sidebar reveal">
            <h5>
              <i className="bi bi-stars me-2"></i>
              Top Picks
              <span className="float-end text-muted-2 small">
                Refresh
              </span>
            </h5>

            {topPicks.map((pick, index) => (
              <div
                key={pick.id}
                className={`d-flex align-items-center gap-3 py-2 ${
                  index !== topPicks.length - 1
                    ? "border-bottom"
                    : ""
                }`}
                style={{
                  borderColor:
                    "var(--border)",
                }}
              >
                <img
                  className="avatar"
                  src={pick.image}
                  alt={pick.name}
                />

                <div>
                  <strong>
                    {pick.name}, {pick.age}
                  </strong>

                  <div className="small text-muted-2">
                    {pick.match}
                  </div>
                </div>
              </div>
            ))}

            <div
              className="card-spark mt-3 text-center"
              style={{ padding: "16px" }}
            >
              <i
                className="bi bi-stars"
                style={{
                  color: "var(--accent)",
                  fontSize: "1.5rem",
                }}
              ></i>

              <h6 className="mt-2">Upgrade to Gold</h6>

              <p className="small text-muted-2 mb-2">
                See unlimited top picks and who already liked you.
              </p>

              <a
                className="btn btn-spark btn-sm w-100"
                href="/signup"
              >
                Upgrade Now
              </a>
            </div>
          </div>
        </aside>
      </div>
    </main>
  );
};

export default Discover;